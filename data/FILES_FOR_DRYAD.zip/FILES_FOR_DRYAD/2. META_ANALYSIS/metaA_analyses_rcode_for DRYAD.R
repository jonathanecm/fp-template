##########################################################################################
###############   ASSESSING P-CURVES OBTAINED FROM METAANALYSES    #######################
##########################################################################################

####### Data taken from: phacking_metA_data for DRYAD.xlsx

##### Results presented in Table 2 and Figure 2 of "The extent and consequences of p-hacking in science" by Megan L. Head, Luke Holman, Rob Lanfear, Andrew, T. Kahn & Michael D. Jennions



####  Two-tailed Binomial tests testing for evidential value for p-curves constructed from meta-analyses

### tests proportion of p values in upper bin (0.025<= p < 0.05) to those in lower bin (0 < p < 0.025)

#Ackay(1)
binom.test(9,35,alternative="two.sided")

#Ackay(2)
binom.test(1,8,alternative="two.sided")

#Ackay(3)
binom.test(2,3,alternative="two.sided")

#Cleasby
binom.test(4,16,alternative="two.sided")

#deJong
binom.test(1,23,alternative="two.sided")

#Jiang
binom.test(82,400,alternative="two.sided")

#Kelly(1)
binom.test(23,106,alternative="two.sided")

#Kelly(2)
binom.test(18,109,alternative="two.sided")

#Kelly(3)
binom.test(18,90,alternative="two.sided")

#Kraaijeveld
binom.test(4,14,alternative="two.sided")

#Prokop
binom.test(15,94,alternative="two.sided")

#Santos
binom.test(23,63,alternative="two.sided")

#Weir(1)
binom.test(2,17,alternative="two.sided")

#Weir(2)
binom.test(1,9,alternative="two.sided")

#Weir(3)
binom.test(1,10,alternative="two.sided")

#Weir(4)
binom.test(2,11,alternative="two.sided")




### One tailed binomial test for p-hacking between 0.04 and 0.05 
### tests proportion of p values in upper bin (0.045< p < 0.05) to those in lower bin (0.04 < p < 0.045)
### including p-values reported as <0.05 but calculated as greater than 0.05

#Ackay(1)
binom.test(1,1,alternative="greater")

#Cleasby
binom.test(2,2,alternative="greater")

#deJong
binom.test(0,0,alternative="greater")

#Jiang
binom.test(17,24,alternative="greater")

#Kelly(1)
binom.test(5,8,alternative="greater")

#Kelly(2)
binom.test(4,6,alternative="greater")

#Kelly(3)
binom.test(6,9,alternative="greater")

#Kraaijeveld
binom.test(1,1,alternative="greater")

#Prokop
binom.test(2,4,alternative="greater")

#Santos
binom.test(2,10,alternative="greater")

#Weir(1)
binom.test(0,0,alternative="greater")

#Weir(4)
binom.test(0,0,alternative="greater")




###Looking for p-hacking between 0.04 and 0.05 
### excluding p-values reported as <0.05 but calculated as greater than 0.05

#Ackay(1)
binom.test(1,1,alternative="greater")

#Cleasby
binom.test(1,1,alternative="greater")

#Jiang
binom.test(11,18,alternative="greater")

#Kelly(1)
binom.test(3,6,alternative="greater")

#Kelly(2)
binom.test(2,4,alternative="greater")

#Kelly(3)
binom.test(1,4,alternative="greater")

#Kraaijeveld
binom.test(1,1,alternative="greater")

#Prokop
binom.test(2,4,alternative="greater")

#Santos
binom.test(2,10,alternative="greater")


